"""Fresh-process reopen/import checks against a build manifest; never saves input.

Run with no input .blend, -- --manifest build-manifest.json --mode blend|glb
--output new-verification.json. GLB validation compares world bounds, mesh names,
triangle counts, material coverage and hierarchy against authored evaluated data.
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parent))
import bpy
from build_scene import scene_metrics
from scene_plan import digest, read_json


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest',required=True,type=Path)
    p.add_argument('--mode',required=True,choices=('blend','glb'))
    p.add_argument('--output',required=True,type=Path)
    args=p.parse_args(sys.argv[sys.argv.index('--')+1:])
    if args.output.exists():
        raise ValueError('Verification output already exists')
    manifest=read_json(args.manifest)
    source=Path(manifest['source_blend'] if args.mode=='blend' else manifest['glb'])
    before=digest(source)
    if args.mode=='blend':
        bpy.ops.wm.open_mainfile(filepath=str(source))
    else:
        bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
        bpy.ops.import_scene.gltf(filepath=str(source))
    actual=scene_metrics();expected=manifest['metrics']
    names_match=set(actual['meshes'])==set(expected['meshes'])
    deviations=[]
    for name,a in actual['meshes'].items():
        if name not in expected['meshes']:
            continue
        e=expected['meshes'][name]
        if max(abs(a['bounds'][i][j]-e['bounds'][i][j]) for i in range(2) for j in range(3))>.002:
            deviations.append(name+': world bounds')
        if a['triangles']!=e['triangles']:
            deviations.append(name+': triangles')
        if not a['materials'] or set(a['materials'])!=set(e['materials']):
            deviations.append(name+': material assignment')
        if a['parent']!=e['parent']:
            deviations.append(name+': parent')
    checks={'source_hash_matches_build':before==manifest['blend_sha256' if args.mode=='blend' else 'glb_sha256'],
            'source_unchanged':before==digest(source),'mesh_names_match':names_match,
            'triangle_count_matches':actual['triangles']==expected['triangles'],
            'no_invalid_vertices':actual['invalid_vertices']==0,
            'no_degenerate_triangles':actual['degenerate_triangles']==0,
            'per_mesh_geometry_material_hierarchy_matches':not deviations,
            'all_meshes_have_uvs':all(bool(o.data.uv_layers) for o in bpy.context.scene.objects if o.type=='MESH')}
    result={'mode':args.mode,'blender_version':bpy.app.version_string,'checks':checks,
            'deviations':deviations,'all_passed':all(checks.values()),'metrics':actual}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('x',encoding='utf-8') as handle:json.dump(result,handle,indent=2)
    print('ASA_VERIFY='+json.dumps(checks))
    if not result['all_passed']:raise RuntimeError('Fresh-process verification failed')


if __name__=='__main__':main()
